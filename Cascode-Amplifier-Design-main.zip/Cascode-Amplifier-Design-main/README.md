# Cascode-Amplifier-Design


– Design of Cascode amplifier, Beta multiplier circuit and Cascode current mirror in schematic and layout using LTspice and
Magic tools in 180 nm (supply 1.8 V) and 22 nm (supply 0.8V) technology.


– The target specifications (i.e., VDD = 1.8V, AV = 20V/V, Power dissipation (PD) < 5mW, Load Capacitance (CL) = 1pF,
Unity Gain Bandwidth(UGB) > 500KHz ) for designing the Cascode amplifier were met.
